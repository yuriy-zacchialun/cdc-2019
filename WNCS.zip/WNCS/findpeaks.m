[~, peaklocs]= findpeaks(y1);
periods = mean(diff(peaklocs));