function [TPM, PEP] = getMarkovChannelForContol(P,mu,sigma,ellF,threshold,steadyProb,Ts,symFreq0,eps_p)  
    
    nChanLev = length(P);    
    PEP(nChanLev) = Inf;            % % % PEP = Packet Error Probability
    th = [-Inf, threshold, +Inf];
    
    for i = 1 : nChanLev
        [V, ~] = getMomentsPER(mu,sigma,th(i),th(i+1),ellF);
        if V < eps_p
            V = 0;  % % % The values under the threshold eps_p are considered pratically 0
        end
        PEP(i) = V/steadyProb(i);
    end
        
    index1 = find (abs(eig(P)) >= 1);
    if length(index1) > 1
        error('      The transition probability matrix of the Markov channel is not ergodic! \n\n')
    end
    clear index1
    if min(min(P)) < 0
        error('      The transition probability matrix of the Markov channel is not stochastic! \n\n')
    end
    
    numJumpsExact = 2*Ts*symFreq0/ellF;
    numJumps = round(numJumpsExact);
    
    TPM = P^numJumps;
    % % % If there are some substochastic rows in TPM, we render them stochastic:
    for i = 1 : size(TPM,2)
        TPM(i,:) = TPM(i,:)./sum(TPM(i,:));
    end

    % % % ----------------------------------------------------------------------------------------------------
%     p =  sum(1-PEP)/nChanLev; % % will be used in Bernoulli channel model for comparison
%     fprintf('The average probability of receiving a packet on this Markov channel is %5.3f.\n\n',p)
    % % % ----------------------------------------------------------------------------------------------------
end