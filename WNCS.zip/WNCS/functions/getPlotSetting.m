function [fSize, mSize, lWidth] = getPlotSetting()
    fSize = 20;
    mSize = 3;
    lWidth = 2.5;
end