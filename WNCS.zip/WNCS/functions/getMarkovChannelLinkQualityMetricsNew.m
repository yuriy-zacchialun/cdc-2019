function [eta_M,var_M,nStarD] = getMarkovChannelLinkQualityMetricsNew(TPM,PEP,steadyProb,eps_b,eps_p,maxLength)
    
    exactValue = 1; % % % It is here for legacy reasons. It should be adjusted
    
    eta_M = PEP*steadyProb';
    fprintf('       eta_M = %9.3f       i.e. expected value of PER over Markov channel\n', eta_M)
    var_M = PEP.^2*steadyProb' - eta_M^2;
    fprintf('   sigma_M^2 = %9.3f       i.e. variance of PER  over Markov channel\n', var_M)
    

    E0 = find(PEP >= eps_p); % % % In order to account for small numerical errors, we have 10*eps_b
    
    numLossyStates = length(E0);
    
    if numLossyStates == length(PEP)
        if length(PEP) > 2
            nStarD = Inf;
            fprintf(...
                '      nStarD = %5u.          i.e. max num of consecutive dropouts; it depends on eps_b\n\n', ...
                nStarD)
            return
        else
            warning('numLossyStates == length(PEP)')
             numLossyStates = 1;
        end
    end
    
    alpha = zeros(1,length(PEP));
    alpha(1) = 1;
    
    P00 = TPM(1:numLossyStates,1:numLossyStates);
    P01 = TPM(1:numLossyStates,numLossyStates+1:end);
    P10 = TPM(numLossyStates+1:end,1:numLossyStates);
    P11 = TPM(numLossyStates+1:end,numLossyStates+1:end);
    
    alpha0 = alpha(1:numLossyStates);
    alpha1 = alpha(numLossyStates+1:end);
    
    v_init = alpha0 + alpha1 * (eye(length(P11)) - P11)^(-1) * P10;
    v_init = v_init / (sum(v_init));            % % % Normalization accounting for numerical errors
    
    mG = (eye(length(P00))-P00)^(-1) * P01 * (eye(length(P11))-P11)^(-1) * P10;
    
    for i = 1 : length(mG)
        mG(i,:) = mG(i,:) / sum(mG(i,:));       % % % Normalization accounting for numerical errors
    end
    
    maxC = maxLength+1;
    PNBnkA = zeros(1,maxC);
    PNBnkB = 1e3*ones(1,maxC);
    PNBnk0 = zeros(100,maxC);
    maxR = 1;
    for k = 1 : maxC
        PNBnkA(k) = v_init * mG^(maxR-1) * P00^(k-1) * (eye(length(P00))-P00) * ones(length(P00),1);
    end    
    while max(abs(PNBnkA-PNBnkB))>eps_b && maxR<101
        PNBnkB = PNBnkA;
        maxR = maxR+1;
        for k = 1 : maxC
            PNBnkA(k) = v_init * mG^(maxR-1) * P00^(k-1) * (eye(length(P00))-P00) * ones(length(P00),1);
        end
        PNBnk0(maxR-1,:) = PNBnkB;
        PNBnk0(maxR,:)   = PNBnkA;
    end
    PNBnk = PNBnk0(1:maxR,:);
    [~,cols] = find(PNBnk>eps_b);
    if max(cols) > maxLength
       warning('The maximal fading interval for the Markov channel is too long!')
       disp(' ')
       cprintf([0.4940, 0.1840, 0.5560],...
            'Paused due to the warning. Press any key to continue or ctrl+c to abort execution.\n')
       pause
    end
    nStarD = max(cols);
    if max(cols) == maxC && exactValue == 1
        while max(cols) == maxC && maxC < 1e6
            maxC = 2*maxC;
            PNBnkA = zeros(1,maxC);
            PNBnkB = 1e3*ones(1,maxC);
            PNBnk0 = zeros(100,maxC);
            maxR = 1;
            for k = 1 : maxC
                PNBnkA(k) = v_init * mG^(maxR-1) * P00^(k-1) * (eye(length(P00))-P00) * ones(length(P00),1);
            end    
            while max(abs(PNBnkA-PNBnkB))>eps_b && maxR<101
                PNBnkB = PNBnkA;
                maxR = maxR+1;
                for k = 1 : maxC
                    PNBnkA(k) = v_init*mG^(maxR-1)*P00^(k-1)*(eye(length(P00))-P00)*ones(length(P00),1);
                end
                PNBnk0(maxR-1,:) = PNBnkB;
                PNBnk0(maxR,:)   = PNBnkA;
            end
            PNBnk = PNBnk0(1:maxR,:);
            [~,cols] = find(PNBnk>eps_b);
        end
        nStarD = max(cols);
    end
    
    fprintf('      nStarD = %5u.          i.e. max num of consecutive dropouts; it depends on eps_b\n\n', ...
        nStarD)  
    
    % % % ----------------------------------------------------------------------------------------------------
    % % % [Rubino & Sericola, 1989]. Rubino, G. and Sericola, B., 1989. 
    % % %       Sojourn times in finite Markov processes. Journal of Applied Probability, 26(4), pp.744-756.
    % % % ----------------------------------------------------------------------------------------------------
end