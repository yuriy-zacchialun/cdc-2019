The folder 'WNCS' contains all necessary MARTLAB code to perform the computation and analysis of the TCP-like optimal networked state-feedback control over WirelessHART communication channel modelled as first order Markov chain.

The structure of the code is standard and intuitive.

The 'main.m' script is the main file allowing to perform all the procedures.
The parameters of various parts are accessible from 'config.m' script. 

In order to be able to execute the scrips correctly, add the 'WNCS' folder with all its subfolders to the MATLAB's search path. If the assistance is needed, type 'help path' in the command window for additional details on setting search path on various operating systems. Please be aware of possible conflicts with existing projects.

All the binary MAT-files that store workspace variables are saved and loaded from 'WNCS' folder. All the produced figures are saved in 'figures' subfolder.